package com.mycompany.app.model;

//this is a POJO class
public class Customer {

	private int cno;
	private String cname;
	private double orderValue;
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Customer(int cno, String cname, double orderValue) {
		super();
		this.cno = cno;
		this.cname = cname;
		this.orderValue = orderValue;
	}

	public int getCno() {
		return cno;
	}
	public void setCno(int cno) {
		this.cno = cno;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public double getOrderValue() {
		return orderValue;
	}
	public void setOrderValue(double orderValue) {
		this.orderValue = orderValue;
	}

	@Override
	public String toString() {
		return "Customer [cno=" + cno + ", cname=" + cname + ", orderValue=" + orderValue + "]";
	}	
	
}
