package com.mycompany.app;

public class Employee  extends Person{
	
	int employeeNumber;
	
	//Property based injection/setter based injection - define the address object reference as one of the property in Employee class
	private Address address;

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public int getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

}
