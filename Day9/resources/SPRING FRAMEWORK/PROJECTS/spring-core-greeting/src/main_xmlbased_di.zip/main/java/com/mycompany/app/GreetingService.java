package com.mycompany.app;

public class GreetingService {
	public String hello() {
		return "Hello, Spring!";
	}

}
