package com.mycompany.app.model;

public interface NotificationService {
	void sendNotification(String message);

}
