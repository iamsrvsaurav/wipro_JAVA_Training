package com.mycompany.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mycompany.app.model.Customer;
import com.mycompany.app.model.EmailNotification;
import com.mycompany.app.model.Mentor;
import com.mycompany.app.model.SMSNotification;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        //Load the Spring Context - Creating the Spring Container
      //  ApplicationContext context = new ClassP
        ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
        
        
        //GreetingService greetService = new GreetingService()
        //Fetch the bean using id which defined in the context / beans xml
        GreetingService greetService = (GreetingService) context.getBean("greetingService");
        
        WelcomeService welcomeService = (WelcomeService) context.getBean("welcomeService");
        //(int) - 
        
        //
        System.out.println(greetService.hello());
        System.out.println(welcomeService.welcome());
        
        welcomeService.sayWelcomeWithMessage();
        
        //Accessing with class - constructor based injection
        Book book = context.getBean(Book.class);
        System.out.println(book);
        book.setId(7895);
        book.setName("Spring Tutorials");
        System.out.println(book);
        
        //setter based injection
        Address addr = context.getBean(Address.class);
        
        
        Employee emp = context.getBean(Employee.class);
        emp.setAddress(addr);
        System.out.println("Employee Name :"+emp.getName());
        System.out.println("Employee Number :"+emp.getEmployeeNumber());
        System.out.println("Employee Address :"+emp.getAddress());
        
        Customer c1 = (Customer) context.getBean("customer1");
		System.out.println(" output: " + c1);
		
        Customer c2 = (Customer) context.getBean("customer2");
		System.out.println(" output: " + c2);
		
		
		Mentor m1 = (Mentor) context.getBean("mentor1");
		m1.display();
		
		EmailNotification email = context.getBean(EmailNotification.class);
		email.sendNotification("Monday Morning Meeting scheduled @ 11 am");
		
		SMSNotification sms = context.getBean(SMSNotification.class);
		sms.sendNotification("Meeting postponded to 12 pm");

		//property based injection
        Car car = context.getBean(Car.class);
        System.out.println(car);
        
    }
}
